## INSTALLATION

1. go to Chrome Menu > Tools > Extensions
2. Check "Developer Mode" if not already checked.
3. Click "Load unpacked extension"
4. Select the folder downloaded for the CodeSpeak extension
